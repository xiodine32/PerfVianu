//DRAWER

#include <winsock2.h>
#include <windows.h>
#include <vadefs.h>
#include <stdio.h>
#include <SDL.h>
#include <SDL_opengl.h>

SOCKET client;
void drawText(int x,int y,double size,double r,double g,double b,double a,const char *X,...);
char latestData[1024],data[1024];
int SCREEN_WIDTH,SCREEN_HEIGHT;
bool running=true,key[512],keyl[512];
int screen=0;

void waitscreen_u(){

}
void waitscreen_d(){
	drawText(SCREEN_WIDTH/2-strlen("Pregatiti-va!")*32+64,SCREEN_HEIGHT/2-32,64,1,1,1,1,"Pregatiti-va!");
}


#pragma region Data writing
void d(const char *x){
	printf("[DEBUG]%s\n",x);
}
struct {
	double sx,sy;
} chars[512];
void generate_font(){
	char text[]={"abcdefgh\nijklmnop\nqrstuvwx\nyz012345\n6789!@#$\n%^&*()[]\n{}-=_+/\\\n,.<>`~| "};
	double X,Y;
	X=Y=0;
	for (int i=0;text[i]!=0;i++){
		if (text[i]=='\n'){
			X=0;
			Y+=0.125;
			continue;
		}
		chars[text[i]].sx=X;
		chars[text[i]].sy=Y;
		X+=0.125;
	}
}
unsigned int textureID=-1;
void load(){
	SDL_Surface *surface=SDL_LoadBMP("font.bmp");
	unsigned char *s;
	UCHAR *r=new UCHAR[512*512*4];
	long c=-1;
	s=(unsigned char *)surface->pixels;
	for (int i=0;i<512*512*3;i+=3){
			unsigned char R=s[i];
			unsigned char G=s[i+1];
			unsigned char B=s[i+2];
			unsigned char A=255;
			if (R==255 && B==255 && G==0){
				R=G=B=0;
				A=0;
			}
			r[++c]=R;
			r[++c]=G;
			r[++c]=B;
			r[++c]=A;
		}
		glGenTextures(1,&textureID);
		glBindTexture(GL_TEXTURE_2D,textureID);
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexImage2D( GL_TEXTURE_2D, 0, 4, 512, 512, 0,GL_RGBA, GL_UNSIGNED_BYTE,r);
		delete r;
		SDL_FreeSurface(surface);
}
void drawText(int x,int y,double size,double r,double g,double b,double a,const char *X,...){
	va_list arg;
	va_start(arg,X);
	char text[1024]={0};
	vsprintf(text,X,arg);
	for (int i=0;text[i]!=0;i++)
		if (text[i]>='A' && text[i]<='Z')
			text[i]=text[i]-'A'+'a';
	glBindTexture(GL_TEXTURE_2D,textureID);
	int DX=x,DY=y;
	for (int i=0;text[i]!=0;i++){
		if (text[i]==' ') {DX+=size;continue;}
		glBegin(GL_QUADS);
		glTexCoord2d(chars[text[i]].sx,chars[text[i]].sy);
		glVertex2i(DX,DY);
		glTexCoord2d(chars[text[i]].sx,chars[text[i]].sy+0.125);
		glVertex2i(DX,DY+size);
		glTexCoord2d(chars[text[i]].sx+0.125,chars[text[i]].sy+0.125);
		glVertex2i(DX+size,DY+size);
		glTexCoord2d(chars[text[i]].sx+0.125,chars[text[i]].sy);
		glVertex2i(DX+size,DY);
		glEnd();
		DX+=(5*size)/6;
	}


}
#pragma endregion
void e(){
	SDL_Event tmp;
	while (SDL_PollEvent(&tmp)){
		switch (tmp.type){
		case SDL_QUIT:running=false;return;
		case SDL_KEYDOWN:key[tmp.key.keysym.sym]=true;return;
		case SDL_KEYUP:key[tmp.key.keysym.sym]=false;return;

		}
	}
}
void up(){
	if (key[SDLK_ESCAPE])
		running=false;
	switch(screen){
	case 0:waitscreen_u();break;
	}
	keyl=key;
}
void dr(){
	glClear(GL_COLOR_BUFFER_BIT);
	switch(screen){
	case 0:waitscreen_d();break;
	}
	SDL_GL_SwapBuffers();
}

DWORD WINAPI thread(LPVOID arg){
	generate_font();
	SDL_Init(SDL_INIT_VIDEO);
	int w=int(GetSystemMetrics(SM_CXFULLSCREEN)/1.5),h=int(GetSystemMetrics(SM_CYFULLSCREEN)/1.5);
	SCREEN_WIDTH=w;SCREEN_HEIGHT=h;
	SDL_SetVideoMode(w,h,0,SDL_OPENGL);//|SDL_FULLSCREEN);

	glEnable(GL_TEXTURE_2D);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glViewport(0,0,w,h);
	glOrtho(0,w,h,0,-1,1);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	

	load();

	int lTick=SDL_GetTicks();
	while (running){
		e();
		while (SDL_GetTicks()-lTick>1000/60){
			up();
			lTick+=1000/60;
		}
		dr();
	}
	return 0;
}

int main(int a,char **argv){
	char strIPADDR[128]={0};printf("IP ADDRESS:");scanf("%s",&strIPADDR);
	int tmp=0;
	CreateThread(NULL,0,thread,&tmp,0,0);

	WSADATA dat;
	WSAStartup(MAKEWORD(2,2),&dat);
	d("host");
	struct sockaddr_in sin;

	memset( &sin, 0, sizeof sin );
	
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = ((in_addr *)(gethostbyname(strIPADDR)->h_addr))->s_addr;
	sin.sin_port = htons( 1030 );

	client=socket(AF_INET,SOCK_STREAM,0);

	

	if ( connect( client,(sockaddr*)&sin, sizeof sin ) == SOCKET_ERROR )
	{
		d("ERROR CONNECTING");
		return 1;
	}
	memset(strIPADDR,0,sizeof(strIPADDR));
	strcpy(strIPADDR,"data");
	
	while (running){
		if (!(send(client,strIPADDR,sizeof(strIPADDR),0)>0)){d("ERR");running=false;};
		recv(client,data,sizeof(data),0);
		d(data);
		memcpy(latestData,data,sizeof(data));
	}
	return 0;
}