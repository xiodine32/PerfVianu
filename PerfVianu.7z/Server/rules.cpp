#include <stdio.h>
#include <time.h>
#include "rules.h"

void d(const char *data){
	if (!debug) return;
	printf("[DEBUG]%s\n",data);
}
void s(const char *data){
	printf("[INFO]%s\n",data);
}

team echipa[101];
problema probl[101];
int echipe,probleme;
int contest_time=120;
int time_start;
bool started;

void readconfig(){
	FILE *f=fopen("config.txt","r");
	char text[1024];
	fgets(text,1024,f);
	fscanf(f,"\n%d\n",&echipe);
	fgets(text,1024,f);
	fscanf(f,"\n%d\n",&contest_time);
	fgets(text,1024,f);
	fscanf(f,"\n%d\n",&probleme);
	fgets(text,1024,f);fscanf(f,"\n");
	for (int i=1;i<=probleme;i++){
		fscanf(f,"%d ",&probl[i].raspuns);
		probl[i].puncte=10;
		probl[i].rezolvata=false;

	}



	//generate content
	for (int i=1;i<=echipe;i++){
		echipa[i].punctaj=120;
		sprintf(text,"created team %d",i);
		d(text);
	}
	
	fclose(f);
}
void nostart(){
	d("CONTEST NOT STARTED YET");
}

void start_contest(){
	if (!started){
		time_start=clock();
		started=true;
	}
	else
		d("CONTEST ALREADY STARTED");
}

void force_end_contest(){
	if (!started) {nostart();return;}
}

const char *say_time_left(){
	
	char towrite[1024]={"ERROR"};
	if (!started) {nostart();return towrite;}
	sprintf(towrite,"TIME LEFT:%ds\n",contest_time*60-(clock()-time_start)/CLK_TCK);
	return towrite;
}
const char *say_drawables(){
	char towrite[1024]={"ERROR"};
	if (!started) {nostart();return towrite;}
	sprintf(towrite,"%d|%d|",echipe,probleme);
	for (int i=1;i<=echipe;i++)
		sprintf(towrite,"%s%d|",towrite,echipa[i].punctaj);
	for (int i=1;i<=probleme;i++)
		sprintf(towrite,"%s%d|%d|",towrite,probl[i].puncte,probl[i].rezolvata?1:0);
	return towrite;
}