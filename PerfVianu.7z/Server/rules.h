#ifndef RULES
#define RULES

const bool debug=true;


void d(const char *data);
void s(const char *data);
void readconfig();
void start_contest();
void force_end_contest();
const char *say_time_left();
const char *say_drawables();


struct team {
	int punctaj;
} ;
struct problema{
	int raspuns;
	int puncte;
	bool rezolvata;

};

#endif