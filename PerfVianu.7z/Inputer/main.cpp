//CONSOLE CLIENT
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <winsock2.h>
#include <stdio.h>


const bool debug=true;
bool recieved=false;
bool running=true;

void d(const char *data){
	if (!debug) return;
	printf("[DEBUG]%s\n",data);
}

SOCKET client;
char sendText[1024]={0},recvText[1024]={0};
int handle_text(const char *text){
	if (strcmp(text,"start")==0){
		printf("******************\n*STARTING CONTEST*\n******************\n");
		strcpy(sendText,"start");
		return 1;
	}
	if (strcmp(text,"timeleft")==0){
		strcpy(sendText,"time");
		return 1;
	}
	printf("COMMAND NOT FOUND\n");	
	return 0;
}

DWORD WINAPI listener(LPVOID arg){
	while (running){
		if (recv(client,recvText,sizeof(recvText),0)>0){
			recieved=true;
			d("RECIEVED TEXT");
		}
		Sleep(10);
	}
	return 0;
}
bool newData=false;
char toSend[1024]={0};
DWORD WINAPI sender(LPVOID arg){
	char tmp[1024]={"ok"};
	if (newData){
		newData=false;
	}
	else
		strcpy(toSend,tmp);
	while (running){
		send(client,toSend,sizeof(toSend),0);
	}
	return 0;
}
int main(){
	char text[1024]={"127.0.0.1"};
	printf("ENTER SERVER IP:");scanf("%s",&text);
	WSADATA dat;
	WSAStartup(MAKEWORD(2,2),&dat);
	d("start");
	d("host");
	struct sockaddr_in sin;

	memset( &sin, 0, sizeof sin );
	
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = ((in_addr *)(gethostbyname(text)->h_addr))->s_addr;
	sin.sin_port = htons( 1030 );

	client=socket(AF_INET,SOCK_STREAM,0);

	

	if ( connect( client,(sockaddr*)&sin, sizeof sin ) == SOCKET_ERROR )
	{
		d("ERROR CONNECTING");
		return 1;
	}
	CreateThread(NULL,0,listener,&text,0,0);
	memset(text,0,sizeof(text));
	strcpy(text,"IAMCLIENT");
	CreateThread(NULL,0,sender,&text,0,0);
	while (running){
		printf("<SERVER>:");scanf("%s",&text);
		if (handle_text(text))
			if (!(send(client,sendText,sizeof(sendText),0)>0)){d("ERR");running=false;};
	
	}
	d("end");
	getchar();
	return 0;
}